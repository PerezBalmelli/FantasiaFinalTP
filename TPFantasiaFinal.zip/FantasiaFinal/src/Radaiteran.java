
public class Radaiteran extends Raza{

	public Radaiteran() {
		super(56, 36);
	}
}
